package kr.co.twocamp.camp;

import java.util.List;

public interface CampService {

	public List<CampBean> camplist();

}
