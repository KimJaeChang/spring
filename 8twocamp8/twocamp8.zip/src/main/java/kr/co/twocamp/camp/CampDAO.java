package kr.co.twocamp.camp;

import java.util.List;

public interface CampDAO {

	public List<CampBean> camplist();

}
