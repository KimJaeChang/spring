package kr.co.Board;

import java.util.List;

public class LikeDTO {
	private int like_number;
	private int b_number;
	private String mb_id;

	
	public int getLike_number() {
		return like_number;
	}
	public void setLike_number(int like_number) {
		this.like_number = like_number;
	}
	public int getB_number() {
		return b_number;
	}
	public void setB_number(int b_number) {
		this.b_number = b_number;
	}
	public String getMb_id() {
		return mb_id;
	}
	public void setMb_id(String mb_id) {
		this.mb_id = mb_id;
	}

	public void addList(LikeDTO likeDTO) {
		// TODO Auto-generated method stub
		
	}
	
	
}
