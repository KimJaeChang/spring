CREATE TABLE `board` (
  `b_number` int NOT NULL AUTO_INCREMENT,
  `b_title` varchar(45) NOT NULL,
  `b_content` varchar(200) NOT NULL,
  `b_id` varchar(45) NOT NULL,
  `b_regdate` int NOT NULL,
  `b_readcnt` int NOT NULL,
  `b_etc` varchar(45) DEFAULT NULL,
  `b_del` int NOT NULL DEFAULT '0',
  `bcode_number` int DEFAULT NULL,
  `pd_number` int DEFAULT NULL,
  `pd_star` double DEFAULT NULL,
  PRIMARY KEY (`b_number`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ;

CREATE TABLE `board_code` (
  `bcode_number` int NOT NULL,
  `bcode_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`bcode_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

CREATE TABLE `board_reply` (
  `re_number` int NOT NULL AUTO_INCREMENT,
  `re_writer` varchar(45) NOT NULL,
  `re_content` varchar(45) NOT NULL,
  `re_date` datetime DEFAULT NULL,
  `b_number` int DEFAULT NULL,
  PRIMARY KEY (`re_number`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ;

CREATE TABLE `cart` (
  `cart_number` int NOT NULL AUTO_INCREMENT,
  `mb_number` int NOT NULL,
  `pd_number` int NOT NULL,
  `cart_amount` int NOT NULL,
  `cart_totalPrice` int NOT NULL,
  `cart_del` int DEFAULT NULL,
  PRIMARY KEY (`cart_number`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ;

CREATE TABLE `like1` (
  `like_number` int NOT NULL AUTO_INCREMENT,
  `b_number` int NOT NULL,
  `mb_id` varchar(45) NOT NULL,
  PRIMARY KEY (`like_number`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ;

CREATE TABLE `members` (
  `mb_number` int NOT NULL AUTO_INCREMENT,
  `mb_id` varchar(45) DEFAULT NULL,
  `mb_pw` varchar(45) DEFAULT NULL,
  `mb_name` varchar(45) DEFAULT NULL,
  `mb_email` varchar(100) DEFAULT NULL,
  `mb_ph` varchar(100) DEFAULT NULL,
  `mb_signup` date DEFAULT NULL,
  `mb_ad1` varchar(50) DEFAULT NULL,
  `mb_ad2` varchar(45) DEFAULT NULL,
  `mb_ad3` varchar(200) DEFAULT NULL,
  `mb_del` int DEFAULT NULL,
  PRIMARY KEY (`mb_number`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 ;

CREATE TABLE `memberauth` (
  `mb_email` varchar(45) NOT NULL,
  `authKey` varchar(45) NOT NULL,
  PRIMARY KEY (`mb_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

CREATE TABLE `order_seq` (
  `ods_number` int NOT NULL AUTO_INCREMENT,
  `od_id` varchar(40) DEFAULT NULL,
  `od_amount` int DEFAULT NULL,
  `pd_number` int DEFAULT NULL,
  PRIMARY KEY (`ods_number`)
) ENGINE=InnoDB AUTO_INCREMENT=266 DEFAULT CHARSET=utf8 ;

CREATE TABLE `orders` (
  `od_number` int NOT NULL AUTO_INCREMENT,
  `od_id` varchar(45) DEFAULT NULL,
  `od_name` varchar(45) DEFAULT NULL,
  `od_price` int DEFAULT NULL,
  `od_ph` varchar(45) DEFAULT NULL,
  `od_ad1` varchar(45) DEFAULT NULL,
  `od_ad2` varchar(45) DEFAULT NULL,
  `od_ad3` varchar(45) DEFAULT NULL,
  `od_date` date DEFAULT NULL,
  `od_state` int DEFAULT NULL,
  `od_memo` varchar(45) DEFAULT NULL,
  `od_delivery` int DEFAULT NULL,
  `mb_number` int DEFAULT NULL,
  PRIMARY KEY ( `od_number`)
  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 ;
  
  CREATE TABLE `product` (
  `pd_number` int NOT NULL AUTO_INCREMENT,
  `pd_name` varchar(45) NOT NULL,
  `pd_price` int NOT NULL,
  `pd_category` varchar(45) DEFAULT NULL,
  `pd_memo` varchar(45) DEFAULT NULL,
  `pd_detail` varchar(45) DEFAULT NULL,
  `pd_company` varchar(45) NOT NULL,
  `pd_stock` int NOT NULL,
  `pd_img` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`pd_number`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 ;





